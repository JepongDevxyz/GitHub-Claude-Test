package com.jepongdevxyz.idebuild;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.SystemClock;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.jepongdevxyz.idebuild.core.ProjectImportService;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Locale;
import java.util.concurrent.ExecutorService;

/** Coordinates real ZIP/folder project imports and their responsive progress UI. */
public final class ProjectImportController {
    private static final long UI_PROGRESS_INTERVAL_MS = 180L;
    private static final int SOURCE_COPY_BUFFER_BYTES = 64 * 1024;
    private static final long STORAGE_PROBE_BYTES = 8L * 1024L * 1024L;
    private static final long STORAGE_PROBE_INTERVAL_MS = 1000L;
    private static final long MIN_FREE_SPACE_RESERVE_BYTES = 128L * 1024L * 1024L;
    private static final String RECOVERY_DIR = "project-import-recovery";
    private static final String PART_SUFFIX = ".part";
    private static final String READY_SUFFIX = ".ready.zip";

    public interface Listener {
        File getProjectStorageDirectory() throws IOException;
        void onImportMessage(String message);
        void onProjectImported(File projectRoot);
    }

    private final Activity activity;
    private final ExecutorService io;
    private final Listener listener;
    private final Object stateLock = new Object();

    private volatile ImportCancellation cancellation;
    private volatile InputStream activeInput;
    private volatile File activeStagedSource;
    private volatile boolean busy;
    private AlertDialog progressDialog;
    private TextView filesText;
    private TextView copiedText;
    private TextView currentText;
    private long lastUiProgressAt;
    private long lastStorageProbeBytes;
    private long lastStorageProbeAt;

    public ProjectImportController(Activity activity, ExecutorService io, Listener listener) {
        if (activity == null) throw new IllegalArgumentException("activity must not be null");
        if (io == null) throw new IllegalArgumentException("io must not be null");
        if (listener == null) throw new IllegalArgumentException("listener must not be null");
        this.activity = activity;
        this.io = io;
        this.listener = listener;
    }

    public boolean isBusy() { return busy; }

    /**
     * Imports a SAF ZIP in two bounded-memory phases:
     * 1) copy provider data into an app-private recovery ZIP;
     * 2) extract the local ZIP using ZipFile entry streams.
     *
     * If Android kills the process during phase 2, the .ready.zip survives and
     * recoverInterruptedZipImport() retries it on the next app launch.
     */
    public void importZip(final Uri uri) {
        if (uri == null || !beginImport("Importing Project")) return;
        final String displayName = displayName(uri, "project.zip");
        listener.onImportMessage("Importing ZIP: " + displayName);
        io.execute(new Runnable() {
            @Override public void run() {
                File staged = null;
                try {
                    final ImportCancellation token = cancellation;
                    final File projects = listener.getProjectStorageDirectory();
                    ProjectImportService.cleanupStaleImports(projects);
                    staged = stageZip(uri, displayName, token);
                    activeStagedSource = staged;
                    listener.onImportMessage("ZIP staged safely: " + staged.getName());
                    ProjectImportService.ImportResult result = importStagedZip(staged, projects, displayName, token);
                    deleteQuietly(staged);
                    activeStagedSource = null;
                    finishSuccess(result.getProjectRoot());
                } catch (OutOfMemoryError memory) {
                    if (staged != null) deleteQuietly(staged);
                    activeStagedSource = null;
                    System.gc();
                    finishFailure(new IOException("Import ran out of memory; the staged source was cleaned up. Try again after closing other apps."));
                } catch (Exception e) {
                    if (staged != null) deleteQuietly(staged);
                    activeStagedSource = null;
                    finishFailure(e);
                } finally {
                    activeInput = null;
                }
            }
        });
    }

    /**
     * Called once after MainActivity wiring. A fully staged ZIP left by abrupt
     * process death is resumed automatically. Incomplete .part files are
     * discarded because they were never declared durable.
     */
    public void recoverInterruptedZipImport() {
        if (busy) return;
        final File recovery = recoveryDirectory();
        File[] files = recovery.listFiles();
        if (files == null || files.length == 0) return;

        File newestReady = null;
        for (File file : files) {
            if (file.getName().endsWith(PART_SUFFIX)) {
                deleteQuietly(file);
                continue;
            }
            if (!file.getName().endsWith(READY_SUFFIX) || !file.isFile()) continue;
            if (newestReady == null || file.lastModified() > newestReady.lastModified()) newestReady = file;
        }
        if (newestReady == null) return;

        final File staged = newestReady;
        final String displayName = recoveredDisplayName(staged);
        if (!beginImport("Resuming Project Import")) return;
        listener.onImportMessage("Recovering interrupted ZIP import: " + displayName);
        io.execute(new Runnable() {
            @Override public void run() {
                try {
                    final ImportCancellation token = cancellation;
                    final File projects = listener.getProjectStorageDirectory();
                    ProjectImportService.cleanupStaleImports(projects);
                    activeStagedSource = staged;
                    ProjectImportService.ImportResult result = importStagedZip(staged, projects, displayName, token);
                    deleteQuietly(staged);
                    activeStagedSource = null;
                    finishSuccess(result.getProjectRoot());
                } catch (OutOfMemoryError memory) {
                    deleteQuietly(staged);
                    activeStagedSource = null;
                    System.gc();
                    finishFailure(new IOException("Recovered import ran out of memory; the staged source was cleaned up."));
                } catch (Exception e) {
                    deleteQuietly(staged);
                    activeStagedSource = null;
                    finishFailure(e);
                }
            }
        });
    }

    private ProjectImportService.ImportResult importStagedZip(File staged,
                                                               File projects,
                                                               String displayName,
                                                               final ImportCancellation token) throws IOException {
        return ProjectImportService.importProject(
                staged,
                projects,
                displayName,
                token,
                new ProjectImportService.ProgressListener() {
                    @Override public void onProgress(int entries, long expandedBytes) {
                        postProgress(entries, expandedBytes, "Extracting staged ZIP…");
                    }
                },
                new ProjectImportService.StorageProbe() {
                    @Override public void check(File destinationRoot, long expandedBytes) throws IOException {
                        checkStorage(destinationRoot, expandedBytes);
                    }
                });
    }

    private File stageZip(Uri uri, String displayName, ImportCancellation token) throws IOException {
        File recovery = recoveryDirectory();
        if (!recovery.isDirectory() && !recovery.mkdirs()) throw new IOException("Cannot create import recovery directory");
        cleanupPartialSources(recovery);

        String safe = sanitizeName(displayName);
        File part = new File(recovery, "import-" + System.currentTimeMillis() + "-" + safe + PART_SUFFIX);
        File ready = new File(recovery, "import-" + System.currentTimeMillis() + "-" + safe + READY_SUFFIX);

        InputStream raw = null;
        BufferedInputStream input = null;
        FileOutputStream fileOutput = null;
        BufferedOutputStream output = null;
        boolean complete = false;
        long copied = 0L;
        try {
            ContentResolver resolver = activity.getContentResolver();
            raw = resolver.openInputStream(uri);
            if (raw == null) throw new IOException("Cannot open ZIP input stream");
            input = new BufferedInputStream(raw, SOURCE_COPY_BUFFER_BYTES);
            activeInput = input;
            activeStagedSource = part;

            fileOutput = new FileOutputStream(part);
            output = new BufferedOutputStream(fileOutput, SOURCE_COPY_BUFFER_BYTES);
            byte[] buffer = new byte[SOURCE_COPY_BUFFER_BYTES];
            int read;
            while ((read = input.read(buffer)) != -1) {
                checkCancelled(token);
                output.write(buffer, 0, read);
                copied += read;
                checkStorage(recovery, copied);
                postProgress(0L, copied, "Staging selected ZIP safely…");
            }
            output.flush();
            fileOutput.getFD().sync();
            closeQuietly(output); output = null;
            closeQuietly(fileOutput); fileOutput = null;
            closeQuietly(input); input = null;
            activeInput = null;

            checkCancelled(token);
            if (!part.renameTo(ready)) throw new IOException("Could not finalize staged ZIP source");
            activeStagedSource = ready;
            complete = true;
            return ready;
        } finally {
            closeQuietly(output);
            closeQuietly(fileOutput);
            closeQuietly(input);
            if (input == null) closeQuietly(raw);
            activeInput = null;
            if (!complete) deleteQuietly(part);
        }
    }

    public void importFolder(final Uri treeUri) {
        if (treeUri == null || !beginImport("Importing Project Folder")) return;
        final String displayName = treeDisplayName(treeUri);
        listener.onImportMessage("Importing folder: " + displayName);
        io.execute(new Runnable() {
            @Override public void run() {
                try {
                    final ImportCancellation token = cancellation;
                    final File projects = listener.getProjectStorageDirectory();
                    ProjectImportService.cleanupStaleImports(projects);
                    final ContentResolver resolver = activity.getContentResolver();
                    ProjectImportService.ImportResult result = ProjectImportService.importPreparedProject(
                            projects,
                            displayName,
                            token,
                            new ProjectImportService.StagingWriter() {
                                @Override public String write(final File stagingDirectory,
                                                              ProjectImportService.CancellationSignal signal) throws IOException {
                                    SafProjectTreeCopier.CopyResult copied = SafProjectTreeCopier.copyTree(
                                            resolver,
                                            treeUri,
                                            stagingDirectory,
                                            signal,
                                            new SafProjectTreeCopier.ProgressListener() {
                                                @Override public void onProgress(long filesProcessed,
                                                                                 long bytesCopied,
                                                                                 String currentRelativePath) {
                                                    postProgress(filesProcessed, bytesCopied, currentRelativePath);
                                                }
                                            },
                                            new ProjectImportService.StorageProbe() {
                                                @Override public void check(File destinationRoot, long expandedBytes) throws IOException {
                                                    checkStorage(destinationRoot, expandedBytes);
                                                }
                                            });
                                    return copied.getProjectRootRelativePath();
                                }
                            });
                    finishSuccess(result.getProjectRoot());
                } catch (OutOfMemoryError memory) {
                    System.gc();
                    finishFailure(new IOException("Folder import ran out of memory. The partial import was cleaned up."));
                } catch (Exception e) {
                    finishFailure(e);
                }
            }
        });
    }

    public void cancel() {
        ImportCancellation token = cancellation;
        if (token != null) token.cancelled = true;
        InputStream stream = activeInput;
        if (stream != null) closeQuietly(stream);
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (currentText != null) currentText.setText("Canceling safely…");
                Button button = progressDialog == null ? null : progressDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
                if (button != null) button.setEnabled(false);
            }
        });
    }

    private boolean beginImport(final String title) {
        synchronized (stateLock) {
            if (busy) return false;
            busy = true;
            cancellation = new ImportCancellation();
            lastUiProgressAt = 0L;
            lastStorageProbeBytes = Long.MIN_VALUE;
            lastStorageProbeAt = 0L;
        }
        activity.runOnUiThread(new Runnable() {
            @Override public void run() { showProgressDialog(title); }
        });
        return true;
    }

    private void showProgressDialog(String title) {
        LinearLayout content = new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        int padding = dp(20);
        content.setPadding(padding, dp(8), padding, dp(4));

        ProgressBar progress = new ProgressBar(activity);
        progress.setIndeterminate(true);
        content.addView(progress, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        filesText = new TextView(activity);
        filesText.setText("Files: preparing…");
        content.addView(filesText);

        copiedText = new TextView(activity);
        copiedText.setText("Processed: 0 B");
        content.addView(copiedText);

        currentText = new TextView(activity);
        currentText.setText("Current: preparing source…");
        currentText.setMaxLines(2);
        content.addView(currentText);

        progressDialog = new AlertDialog.Builder(activity)
                .setTitle(title)
                .setView(content)
                .setNegativeButton("Cancel", null)
                .create();
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override public void onShow(DialogInterface dialog) {
                Button cancelButton = progressDialog.getButton(DialogInterface.BUTTON_NEGATIVE);
                cancelButton.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) { cancel(); }
                });
            }
        });
        progressDialog.show();
    }

    private void postProgress(final long files, final long bytes, final String current) {
        long now = SystemClock.uptimeMillis();
        if (now - lastUiProgressAt < UI_PROGRESS_INTERVAL_MS) return;
        lastUiProgressAt = now;
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (!busy) return;
                if (filesText != null) filesText.setText(files <= 0L ? "Files: staging source" : "Files: " + files + " processed");
                if (copiedText != null) copiedText.setText("Processed: " + humanBytes(bytes));
                if (currentText != null) currentText.setText("Current: " + (current == null ? "…" : current));
            }
        });
    }

    private void checkStorage(File destinationRoot, long processedBytes) throws IOException {
        if (cancellation != null && cancellation.isCancelled()) {
            throw new ProjectImportService.ImportCanceledException();
        }
        long now = SystemClock.uptimeMillis();
        if (lastStorageProbeBytes != Long.MIN_VALUE &&
                processedBytes >= lastStorageProbeBytes &&
                processedBytes - lastStorageProbeBytes < STORAGE_PROBE_BYTES &&
                now - lastStorageProbeAt < STORAGE_PROBE_INTERVAL_MS) {
            return;
        }
        lastStorageProbeBytes = processedBytes;
        lastStorageProbeAt = now;

        File probe = destinationRoot;
        while (probe != null && !probe.exists()) probe = probe.getParentFile();
        if (probe == null) throw new IOException("Import destination is unavailable");
        long usable = probe.getUsableSpace();
        if (usable <= MIN_FREE_SPACE_RESERVE_BYTES) {
            throw new IOException("Not enough free storage (keep at least " + humanBytes(MIN_FREE_SPACE_RESERVE_BYTES) + " free)");
        }
    }

    private void finishSuccess(final File projectRoot) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                clearBusyState();
                listener.onImportMessage("IMPORT COMPLETE: " + projectRoot.getAbsolutePath());
                listener.onProjectImported(projectRoot);
            }
        });
    }

    private void finishFailure(final Exception failure) {
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                boolean canceled = failure instanceof ProjectImportService.ImportCanceledException ||
                        (cancellation != null && cancellation.isCancelled());
                clearBusyState();
                if (canceled) {
                    listener.onImportMessage("IMPORT CANCELED");
                    showResultDialog("Import canceled", "The partial import was not activated as a project.");
                    return;
                }
                String detail = friendlyError(failure);
                listener.onImportMessage("IMPORT ERROR: " + detail);
                showResultDialog("Import failed", detail);
            }
        });
    }

    private void clearBusyState() {
        synchronized (stateLock) {
            busy = false;
            cancellation = null;
            activeInput = null;
            activeStagedSource = null;
        }
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
        filesText = null;
        copiedText = null;
        currentText = null;
    }

    private void showResultDialog(String title, String message) {
        if (activity.isFinishing()) return;
        new AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private String friendlyError(Exception failure) {
        String message = failure.getMessage();
        if (message == null || message.trim().length() == 0) message = failure.getClass().getSimpleName();
        String lower = message.toLowerCase(Locale.US);
        if (lower.contains("enospc") || lower.contains("no space left") || lower.contains("not enough free storage")) {
            return "Not enough free storage. The partial import was cleaned up.";
        }
        if (lower.contains("permission") || failure instanceof SecurityException) {
            return "Permission denied while reading the selected source.";
        }
        if (lower.contains("unsafe zip") || lower.contains("escaped the staging") || lower.contains("absolute zip")) {
            return "The archive contains an unsafe path and was rejected.";
        }
        if (lower.contains("zip") && (lower.contains("invalid") || lower.contains("corrupt") || lower.contains("error"))) {
            return "The ZIP archive is invalid or corrupted.";
        }
        return message;
    }

    private File recoveryDirectory() {
        return new File(activity.getCacheDir(), RECOVERY_DIR);
    }

    private void cleanupPartialSources(File recovery) {
        File[] files = recovery.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.getName().endsWith(PART_SUFFIX)) deleteQuietly(file);
        }
    }

    private static String sanitizeName(String value) {
        String safe = value == null ? "project.zip" : value.trim();
        safe = safe.replaceAll("[^A-Za-z0-9._-]+", "-");
        while (safe.startsWith(".")) safe = safe.substring(1);
        if (safe.length() == 0) safe = "project.zip";
        if (safe.length() > 80) safe = safe.substring(safe.length() - 80);
        return safe;
    }

    private static String recoveredDisplayName(File staged) {
        String name = staged.getName();
        if (name.endsWith(READY_SUFFIX)) name = name.substring(0, name.length() - READY_SUFFIX.length()) + ".zip";
        int firstDash = name.indexOf('-');
        int secondDash = firstDash < 0 ? -1 : name.indexOf('-', firstDash + 1);
        if (secondDash >= 0 && secondDash + 1 < name.length()) name = name.substring(secondDash + 1);
        return name.length() == 0 ? "recovered-project.zip" : name;
    }

    private String displayName(Uri uri, String fallback) {
        Cursor cursor = null;
        try {
            cursor = activity.getContentResolver().query(uri,
                    new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (column >= 0) {
                    String value = cursor.getString(column);
                    if (value != null && value.length() > 0) return value;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return fallback;
    }

    private String treeDisplayName(Uri treeUri) {
        Cursor cursor = null;
        try {
            String id = DocumentsContract.getTreeDocumentId(treeUri);
            Uri root = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
            cursor = activity.getContentResolver().query(root,
                    new String[] { DocumentsContract.Document.COLUMN_DISPLAY_NAME }, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int column = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                if (column >= 0) {
                    String value = cursor.getString(column);
                    if (value != null && value.length() > 0) return value;
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = treeUri.getLastPathSegment();
        return last == null || last.length() == 0 ? "project" : last.replace(':', '-');
    }

    private int dp(int value) {
        return (int) (value * activity.getResources().getDisplayMetrics().density + 0.5f);
    }

    private static String humanBytes(long bytes) {
        if (bytes < 1024L) return bytes + " B";
        double value = bytes;
        String[] units = { "B", "KiB", "MiB", "GiB", "TiB" };
        int unit = 0;
        while (value >= 1024.0 && unit < units.length - 1) {
            value /= 1024.0;
            unit++;
        }
        return String.format(Locale.US, "%.1f %s", value, units[unit]);
    }

    private static void checkCancelled(ImportCancellation token) throws ProjectImportService.ImportCanceledException {
        if (token != null && token.isCancelled()) throw new ProjectImportService.ImportCanceledException();
    }

    private static void deleteQuietly(File file) {
        if (file != null && file.exists()) file.delete();
    }

    private static void closeQuietly(java.io.Closeable closeable) {
        if (closeable != null) {
            try { closeable.close(); } catch (IOException ignored) { }
        }
    }

    private static final class ImportCancellation implements ProjectImportService.CancellationSignal {
        volatile boolean cancelled;
        @Override public boolean isCancelled() { return cancelled; }
    }
}
