import com.jepongdevxyz.idebuild.core.ProjectImportService;
import com.jepongdevxyz.idebuild.core.ProjectRootTracker;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.nio.file.Files;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Regression tests for project import without an app-defined byte/entry ceiling. */
public final class ProjectImportUnlimitedHostTest {
    private static int passed;

    public static void main(String[] args) throws Exception {
        unlimitedOverloadImportsWithoutPolicyArguments();
        diskBackedZipImportAndStaleCleanupWork();
        rootTrackerFindsDeepSettingsRootWithConstantState();
        System.out.println("PROJECT IMPORT UNLIMITED HOST TESTS PASSED: " + passed + "/3");
    }

    private static void unlimitedOverloadImportsWithoutPolicyArguments() throws Exception {
        File projects = Files.createTempDirectory("devxyz-unlimited-import").toFile();
        try {
            byte[] zip = zip(new String[][] {
                    {"Huge/settings.gradle", "include ':app'"},
                    {"Huge/app/build.gradle", "apply plugin: 'com.android.application'"},
                    {"Huge/app/src/main/AndroidManifest.xml", "<manifest package=\"devxyz.huge\"/>"}
            });
            ProjectImportService.ImportResult result = ProjectImportService.importProject(
                    new ByteArrayInputStream(zip),
                    projects,
                    "Huge.zip",
                    ProjectImportService.NEVER_CANCELLED,
                    ProjectImportService.NO_PROGRESS,
                    ProjectImportService.NO_STORAGE_PROBE);
            assertTrue(new File(result.getProjectRoot(), "settings.gradle").isFile());
            passed++;
        } finally {
            deleteTree(projects);
        }
    }

    private static void diskBackedZipImportAndStaleCleanupWork() throws Exception {
        File root = Files.createTempDirectory("devxyz-disk-import").toFile();
        File projects = new File(root, "projects");
        File zipFile = new File(root, "DiskProject.zip");
        if (!projects.mkdir()) throw new AssertionError("Could not create projects directory");
        try {
            java.io.FileOutputStream fileOutput = new java.io.FileOutputStream(zipFile);
            ZipOutputStream zip = new ZipOutputStream(fileOutput);
            try {
                put(zip, "DiskProject/settings.gradle", "include ':app'");
                put(zip, "DiskProject/app/build.gradle", "apply plugin: 'com.android.application'");
                put(zip, "DiskProject/app/src/main/AndroidManifest.xml", "<manifest package=\"devxyz.disk\"/>");
            } finally { zip.close(); }

            ProjectImportService.ImportResult result = ProjectImportService.importProject(
                    zipFile, projects, "DiskProject.zip",
                    ProjectImportService.NEVER_CANCELLED,
                    ProjectImportService.NO_PROGRESS,
                    ProjectImportService.NO_STORAGE_PROBE);
            assertTrue(new File(result.getProjectRoot(), "settings.gradle").isFile());

            File stale = new File(projects, ".import-crashed-123");
            File staleChild = new File(stale, "nested/file.txt");
            if (!staleChild.getParentFile().mkdirs()) throw new AssertionError("Could not create stale staging parent");
            java.nio.file.Files.write(staleChild.toPath(), "partial".getBytes("UTF-8"));
            int removed = ProjectImportService.cleanupStaleImports(projects);
            assertTrue(removed == 1);
            assertTrue(!stale.exists());
            passed++;
        } finally {
            deleteTree(root);
        }
    }

    private static void put(ZipOutputStream zip, String name, String value) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(value.getBytes("UTF-8"));
        zip.closeEntry();
    }

    private static void rootTrackerFindsDeepSettingsRootWithConstantState() {
        ProjectRootTracker tracker = new ProjectRootTracker();
        tracker.onEntry("outer/one/two/three/app/build.gradle");
        tracker.onEntry("outer/one/two/three/settings.gradle.kts");
        tracker.onEntry("outer/one/two/three/app/src/main/AndroidManifest.xml");
        assertEquals("outer/one/two/three", tracker.getBestRootRelativePath());
        passed++;
    }

    private static byte[] zip(String[][] entries) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        ZipOutputStream zip = new ZipOutputStream(bytes);
        try {
            for (String[] entry : entries) {
                zip.putNextEntry(new ZipEntry(entry[0]));
                zip.write(entry[1].getBytes("UTF-8"));
                zip.closeEntry();
            }
        } finally {
            zip.close();
        }
        return bytes.toByteArray();
    }

    private static void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }

    private static void assertTrue(boolean value) {
        if (!value) throw new AssertionError("Expected true");
    }

    private static void assertEquals(String expected, String actual) {
        if (expected == null ? actual != null : !expected.equals(actual)) {
            throw new AssertionError("Expected " + expected + " but was " + actual);
        }
    }
}
