import com.jepongdevxyz.idebuild.core.build.ProjectTemplateGenerator;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public final class ProjectTemplateGeneratorHostTest {
    private static int passed;

    public static void main(String[] args) throws Exception {
        createsClassicJavaProject();
        createsModernAndroidxProject();
        createsModernAndroidxKotlinProject();
        createsNoActivityProject();
        createsWebViewProject();
        createsLibraryProject();
        rejectsUnsafeNamesAndPackages();
        System.out.println("PROJECT TEMPLATE GENERATOR HOST TESTS PASSED: " + passed + "/7");
    }

    private static void createsClassicJavaProject() throws Exception {
        File parent = Files.createTempDirectory("devxyz-classic-template").toFile();
        try {
            File root = ProjectTemplateGenerator.create(parent, "Hello Classic", "com.example.classicapp", ProjectTemplateGenerator.Template.CLASSIC_JAVA);
            assertTrue(new File(root, "settings.gradle").isFile());
            assertTrue(new File(root, "build.gradle").isFile());
            assertTrue(new File(root, "app/build.gradle").isFile());
            assertTrue(new File(root, "app/src/main/AndroidManifest.xml").isFile());
            assertTrue(new File(root, "app/src/main/java/com/example/classicapp/MainActivity.java").isFile());
            String appGradle = read(new File(root, "app/build.gradle"));
            String manifest = read(new File(root, "app/src/main/AndroidManifest.xml"));
            assertContains(appGradle, "compileSdkVersion 28");
            assertContains(appGradle, "applicationId 'com.example.classicapp'");
            assertContains(manifest, "package=\"com.example.classicapp\"");
            assertContains(read(new File(root, "build.gradle")), "com.android.tools.build:gradle:3.2.1");
            passed++;
        } finally { deleteTree(parent); }
    }

    private static void createsModernAndroidxProject() throws Exception {
        File parent = Files.createTempDirectory("devxyz-modern-template").toFile();
        try {
            File root = ProjectTemplateGenerator.create(parent, "Hello Modern", "com.example.modernapp", ProjectTemplateGenerator.Template.MODERN_ANDROIDX_JAVA);
            String appGradle = read(new File(root, "app/build.gradle"));
            String rootGradle = read(new File(root, "build.gradle"));
            String manifest = read(new File(root, "app/src/main/AndroidManifest.xml"));
            String activity = read(new File(root, "app/src/main/java/com/example/modernapp/MainActivity.java"));
            assertContains(rootGradle, "com.android.application");
            assertContains(appGradle, "namespace 'com.example.modernapp'");
            assertContains(appGradle, "compileSdk 35");
            assertContains(appGradle, "platform('org.jetbrains.kotlin:kotlin-bom:2.0.21')");
            assertContains(appGradle, "androidx.appcompat:appcompat");
            assertContains(activity, "androidx.appcompat.app.AppCompatActivity");
            assertNotContains(manifest, "package=\"");
            passed++;
        } finally { deleteTree(parent); }
    }

    private static void createsModernAndroidxKotlinProject() throws Exception {
        File parent = Files.createTempDirectory("devxyz-kotlin-template").toFile();
        try {
            File root = ProjectTemplateGenerator.create(parent, "Hello Kotlin", "com.example.kotlinapp", ProjectTemplateGenerator.Template.MODERN_ANDROIDX_KOTLIN);
            String appGradle = read(new File(root, "app/build.gradle"));
            String rootGradle = read(new File(root, "build.gradle"));
            String activity = read(new File(root, "app/src/main/kotlin/com/example/kotlinapp/MainActivity.kt"));
            assertContains(rootGradle, "org.jetbrains.kotlin.android");
            assertContains(rootGradle, "2.0.21");
            assertContains(appGradle, "id 'org.jetbrains.kotlin.android'");
            assertContains(appGradle, "platform('org.jetbrains.kotlin:kotlin-bom:2.0.21')");
            assertContains(appGradle, "namespace 'com.example.kotlinapp'");
            assertContains(appGradle, "compileSdk 35");
            assertContains(appGradle, "    kotlinOptions {\n        jvmTarget = '17'\n    }\n}");
            assertNotContains(appGradle, "\n}\n\nkotlinOptions {");
            assertContains(activity, "class MainActivity : AppCompatActivity()");
            assertContains(activity, "override fun onCreate");
            passed++;
        } finally { deleteTree(parent); }
    }

    private static void createsNoActivityProject() throws Exception {
        File parent = Files.createTempDirectory("devxyz-no-activity-template").toFile();
        try {
            File root = ProjectTemplateGenerator.create(parent, "No Activity", "com.example.noactivity", ProjectTemplateGenerator.Template.NO_ACTIVITY_JAVA);
            String manifest = read(new File(root, "app/src/main/AndroidManifest.xml"));
            String appGradle = read(new File(root, "app/build.gradle"));
            assertContains(appGradle, "id 'com.android.application'");
            assertContains(appGradle, "namespace 'com.example.noactivity'");
            assertNotContains(manifest, "<activity");
            assertFalse(new File(root, "app/src/main/java/com/example/noactivity/MainActivity.java").exists());
            passed++;
        } finally { deleteTree(parent); }
    }

    private static void createsWebViewProject() throws Exception {
        File parent = Files.createTempDirectory("devxyz-webview-template").toFile();
        try {
            File root = ProjectTemplateGenerator.create(parent, "Web App", "com.example.webapp", ProjectTemplateGenerator.Template.WEBVIEW_JAVA);
            String manifest = read(new File(root, "app/src/main/AndroidManifest.xml"));
            String layout = read(new File(root, "app/src/main/res/layout/activity_main.xml"));
            String activity = read(new File(root, "app/src/main/java/com/example/webapp/MainActivity.java"));
            assertContains(manifest, "android.permission.INTERNET");
            assertContains(layout, "<WebView");
            assertContains(activity, "WebView webView");
            assertContains(activity, "setJavaScriptEnabled(false)");
            passed++;
        } finally { deleteTree(parent); }
    }

    private static void createsLibraryProject() throws Exception {
        File parent = Files.createTempDirectory("devxyz-library-template").toFile();
        try {
            File root = ProjectTemplateGenerator.create(parent, "My Library", "com.example.mylibrary", ProjectTemplateGenerator.Template.LIBRARY_JAVA);
            String rootGradle = read(new File(root, "build.gradle"));
            String appGradle = read(new File(root, "app/build.gradle"));
            String manifest = read(new File(root, "app/src/main/AndroidManifest.xml"));
            assertContains(rootGradle, "com.android.library");
            assertContains(appGradle, "id 'com.android.library'");
            assertContains(appGradle, "namespace 'com.example.mylibrary'");
            assertNotContains(appGradle, "applicationId");
            assertNotContains(manifest, "<activity");
            assertTrue(new File(root, "app/src/main/java/com/example/mylibrary/LibraryApi.java").isFile());
            passed++;
        } finally { deleteTree(parent); }
    }

    private static void rejectsUnsafeNamesAndPackages() throws Exception {
        File parent = Files.createTempDirectory("devxyz-template-guard").toFile();
        try {
            expectFailure(new ThrowingRunnable() { @Override public void run() throws Exception {
                ProjectTemplateGenerator.create(parent, "../escape", "com.example.safe", ProjectTemplateGenerator.Template.CLASSIC_JAVA);
            }});
            expectFailure(new ThrowingRunnable() { @Override public void run() throws Exception {
                ProjectTemplateGenerator.create(parent, "Safe", "bad-package", ProjectTemplateGenerator.Template.CLASSIC_JAVA);
            }});
            passed++;
        } finally { deleteTree(parent); }
    }

    private static String read(File file) throws Exception { return new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8); }
    private static void expectFailure(ThrowingRunnable action) throws Exception {
        boolean failed = false;
        try { action.run(); } catch (IllegalArgumentException expected) { failed = true; }
        if (!failed) throw new AssertionError("Expected IllegalArgumentException");
    }
    private static void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }
    private static void assertContains(String value, String expected) {
        if (value.indexOf(expected) < 0) throw new AssertionError("Expected text: " + expected + "\nActual:\n" + value);
    }
    private static void assertNotContains(String value, String unexpected) {
        if (value.indexOf(unexpected) >= 0) throw new AssertionError("Unexpected text: " + unexpected + "\nActual:\n" + value);
    }
    private static void assertTrue(boolean value) { if (!value) throw new AssertionError("Expected true"); }
    private static void assertFalse(boolean value) { if (value) throw new AssertionError("Expected false"); }
    private interface ThrowingRunnable { void run() throws Exception; }
}
