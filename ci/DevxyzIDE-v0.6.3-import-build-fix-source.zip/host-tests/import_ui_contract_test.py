#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MAIN = ROOT / "app/src/main/java/com/jepongdevxyz/idebuild/MainActivity.java"
CONTROLLER = ROOT / "app/src/main/java/com/jepongdevxyz/idebuild/ProjectImportController.java"
TREE = ROOT / "app/src/main/java/com/jepongdevxyz/idebuild/SafProjectTreeCopier.java"

main = MAIN.read_text(encoding="utf-8")

assert "MAX_IMPORT_BYTES" not in main, "MainActivity must not impose a fixed project import byte ceiling"
assert "MAX_IMPORT_ENTRIES" not in main, "MainActivity must not impose a fixed project import entry ceiling"
assert "REQUEST_IMPORT_FOLDER" in main, "Folder import request code missing"
assert "Intent.ACTION_OPEN_DOCUMENT_TREE" in main, "SAF folder picker missing"
assert "Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP" in main, "Folder SAF must be API-gated"
assert "ProjectImportController" in main, "MainActivity must delegate import work to ProjectImportController"
assert "getContentResolver().openInputStream(uri)" not in main or "ProjectImportController" in main

assert CONTROLLER.exists(), "ProjectImportController.java missing"
controller = CONTROLLER.read_text(encoding="utf-8")
assert "ContentResolver" in controller
assert "openInputStream" in controller, "ZIP URI must be opened as a stream"
assert "ProjectImportService.importProject" in controller, "Controller must use atomic import service"
assert "NO_STORAGE_PROBE" not in controller, "Android controller should provide a real storage probe"
assert "getUsableSpace" in controller, "Controller must monitor available workspace storage"
assert "cancel()" in controller, "Cancelable import controller missing"
assert "content://" not in controller or "getPath" not in controller, "Do not convert content URIs to filesystem paths"

assert TREE.exists(), "SafProjectTreeCopier.java missing"
tree = TREE.read_text(encoding="utf-8")
assert "DocumentsContract.buildChildDocumentsUriUsingTree" in tree
assert "ContentResolver" in tree
assert "Cursor" in tree
assert "BufferedInputStream" in tree
assert "BufferedOutputStream" in tree
assert "byte[] buffer" in tree, "Folder import must use a reusable bounded buffer"
assert "read(buffer)" in tree or "read(buffer," in tree
assert "ArrayDeque" in tree, "Folder traversal should be iterative/bounded-stack"


manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
assert 'android:largeHeap="true"' in manifest, "Large project imports should get an IDE-sized heap safety margin"
assert "FLAG_GRANT_PERSISTABLE_URI_PERMISSION" in main, "ZIP/folder SAF access should request persistable permission"
assert "takePersistableUriPermission" in main, "Selected import URIs should persist read access when the provider allows it"
assert "recoverInterruptedZipImport" in main, "MainActivity should resume a fully staged ZIP after process death"
assert "recoverInterruptedZipImport" in controller, "Controller recovery path missing"
assert "project-import-recovery" in controller, "ZIP source must be staged in an app-private recovery directory"
assert ".ready.zip" in controller and ".part" in controller, "Durable vs incomplete staged ZIP states must be distinct"
assert "FileOutputStream" in controller and "getFD().sync()" in controller, "Staged ZIP must be flushed durably before extraction"
assert "ProjectImportService.cleanupStaleImports" in controller, "Orphan import staging directories must be cleaned before retry"
assert "MIN_FREE_SPACE_RESERVE_BYTES" in controller, "Import must keep a safety reserve instead of filling storage to zero"

safe_zip = (ROOT / "app/src/main/java/com/jepongdevxyz/idebuild/core/SafeZip.java").read_text(encoding="utf-8")
assert "ZipFile" in safe_zip, "Staged ZIP extraction should use disk-backed ZipFile entry streams"
assert "PROJECT_PROGRESS_BYTES" in safe_zip, "Large-entry progress callbacks must be byte-throttled"

service = (ROOT / "app/src/main/java/com/jepongdevxyz/idebuild/core/ProjectImportService.java").read_text(encoding="utf-8")
assert "importProject(File sourceZip" in service, "Disk-backed project import overload missing"
assert "cleanupStaleImports" in service, "Stale import cleanup API missing"

print("IMPORT UI CONTRACT TEST PASSED")
