# DevxyzIDE Reference UI Rebuild Checkpoint

Date: 2026-09-26
Package: com.jepongdevxyz.idebuild
Base: recovered DevxyzIDE v0.6.1 official source

## Reference UI changes applied

- Reworked the main shell to follow the approved DevxyzIDE reference visual flow instead of showing Explorer and Editor simultaneously.
- Project Explorer is now its own full workspace with compact app bar, project actions, real lazy file list, and floating New Project action.
- Opening a text/source file automatically switches to the dedicated Code Editor workspace.
- Code Editor keeps real multi-tab state, Save, Save All, completion, editor actions, syntax editor, and Code / Terminal / Log / Problems navigation.
- Build & Run is a dedicated workspace with the real streamed build console plus Build Project, Install APK, and Build Actions.
- Built-in Tools uses a compact grid-style layout while retaining the real Terminal, Git, APK Signer, Developer Tools, and Project Settings controls.
- Settings is a dedicated workspace for editor preferences, SDK/JDK/Gradle/toolchain/runtime, and backup.
- Header shortcuts are wired to real workspace surfaces and actions.
- System Back returns Editor -> Explorer, and non-file workspaces -> Explorer before leaving the app.
- Portrait and landscape use the same feature surfaces and visual language.
- Existing ZIP import, safe explorer mutations, save/search/templates/build diagnostics/install/backup/Git/terminal/toolchain code was preserved.

## Fresh verification performed

Command:

    sh host-tests/run.sh

Result: PASS across the complete recovered host/contract suite, including import, safe ZIP, explorer, editor, search, templates, build planner/diagnostics, APK locator/signing services, terminal/Git, reference UI contracts, landscape contracts, no-exit project flow, and emulator workflow contracts.

See `REFERENCE_UI_HOST_TESTS.log` for the captured output.

## APK build status

A new APK is NOT claimed from this checkpoint. The current execution environment has JDK 21 but does not contain Gradle 4.6, the Gradle wrapper JAR, or Android SDK 29/build-tools, and its shell network cannot resolve external package hosts. The older PR13 APK therefore does not represent this rebuilt UI source.
