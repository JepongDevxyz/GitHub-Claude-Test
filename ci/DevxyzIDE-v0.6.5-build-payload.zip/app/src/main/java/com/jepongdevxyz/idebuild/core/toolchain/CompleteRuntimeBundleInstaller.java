package com.jepongdevxyz.idebuild.core.toolchain;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Installs the complete DevxyzIDE ARM64 build runtime from one verified bundle.
 *
 * Expected outer bundle members:
 * - devxyz-bootstrap-aarch64.zip
 * - gradle-8.9.devxyz-toolchain.zip
 * - android-sdk-35.devxyz-toolchain.zip
 * - SHA256SUMS
 *
 * All inner archives are copied to an app-private staging directory and checked
 * against SHA256SUMS before any component is installed. Each component installer
 * then performs its own structural/path validation as a second verification layer.
 */
public final class CompleteRuntimeBundleInstaller {
    private static final String BOOTSTRAP = "devxyz-bootstrap-aarch64.zip";
    private static final String GRADLE = "gradle-8.9.devxyz-toolchain.zip";
    private static final String SDK = "android-sdk-35.devxyz-toolchain.zip";
    private static final String SUMS = "SHA256SUMS";
    private static final long MAX_BUNDLE_BYTES = 3L * 1024L * 1024L * 1024L;
    private static final long MAX_MEMBER_BYTES = 2L * 1024L * 1024L * 1024L;
    private static final int MAX_ENTRIES = 32;

    private CompleteRuntimeBundleInstaller() {}

    public static InstallResult install(File bundleZip, File appFilesDir, String expectedApplicationId) throws IOException {
        if (bundleZip == null || !bundleZip.isFile()) throw new IOException("Complete runtime bundle not found");
        if (bundleZip.length() <= 0L || bundleZip.length() > MAX_BUNDLE_BYTES) throw new IOException("Complete runtime bundle size is outside the allowed range");
        if (appFilesDir == null) throw new IOException("App files directory is missing");

        File filesRoot = appFilesDir.getCanonicalFile();
        if (!filesRoot.exists() && !filesRoot.mkdirs()) throw new IOException("Cannot create app files directory");
        File staging = new File(filesRoot, ".runtime-bundle-" + System.nanoTime()).getCanonicalFile();
        if (!inside(filesRoot, staging) || !staging.mkdirs()) throw new IOException("Cannot create runtime bundle staging directory");

        try {
            Map<String, String> sums;
            try (ZipFile zip = new ZipFile(bundleZip)) {
                validateOuterEntries(zip);
                sums = readSums(zip);
                requireChecksum(sums, BOOTSTRAP);
                requireChecksum(sums, GRADLE);
                requireChecksum(sums, SDK);
                extractVerified(zip, BOOTSTRAP, sums.get(BOOTSTRAP), new File(staging, BOOTSTRAP));
                extractVerified(zip, GRADLE, sums.get(GRADLE), new File(staging, GRADLE));
                extractVerified(zip, SDK, sums.get(SDK), new File(staging, SDK));
            }

            TerminalBootstrapInstaller.InstallResult bootstrapResult;
            try (InputStream in = new BufferedInputStream(new FileInputStream(new File(staging, BOOTSTRAP)))) {
                bootstrapResult = TerminalBootstrapInstaller.install(in, filesRoot, expectedApplicationId);
            }
            ToolchainPackInstaller.InstallResult gradleResult = ToolchainPackInstaller.install(new File(staging, GRADLE), filesRoot);
            ToolchainPackInstaller.InstallResult sdkResult = ToolchainPackInstaller.install(new File(staging, SDK), filesRoot);

            ToolchainInventory inventory = ToolchainInventory.scan(filesRoot);
            File gradle = RuntimeLayout.findGradleExecutable(filesRoot, "8.9");
            if (gradle == null || !gradle.isFile()) throw new IOException("Runtime installation completed but Gradle 8.9 was not detected");
            if (!inventory.hasAndroidPlatform(35)) throw new IOException("Runtime installation completed but Android platform 35 was not detected");
            if (!inventory.hasAapt2()) throw new IOException("Runtime installation completed but Android-native aapt2 was not detected");
            if (!inventory.hasJdk(21) && !inventory.hasJdk(17)) throw new IOException("Runtime installation completed but no supported JDK was detected");

            return new InstallResult(
                    bootstrapResult.getArch(),
                    bootstrapResult.getFiles(),
                    bootstrapResult.getSymlinks(),
                    gradleResult.getVerifiedFiles(),
                    sdkResult.getVerifiedFiles(),
                    inventory.summary());
        } finally {
            if (staging.exists()) deleteRecursively(staging);
        }
    }

    private static void validateOuterEntries(ZipFile zip) throws IOException {
        Enumeration<? extends ZipEntry> entries = zip.entries();
        int count = 0;
        Set<String> allowed = new HashSet<String>(Arrays.asList(BOOTSTRAP, GRADLE, SDK, SUMS, "runtime-pack.properties"));
        while (entries.hasMoreElements()) {
            ZipEntry entry = entries.nextElement();
            if (++count > MAX_ENTRIES) throw new IOException("Complete runtime bundle has too many entries");
            String name = entry.getName().replace('\\', '/');
            if (entry.isDirectory()) continue;
            if (name.startsWith("/") || name.contains("../") || name.contains("/")) throw new IOException("Unsafe runtime bundle member: " + name);
            if (!allowed.contains(name)) throw new IOException("Unexpected runtime bundle member: " + name);
        }
        for (String required : new String[]{BOOTSTRAP, GRADLE, SDK, SUMS}) {
            ZipEntry entry = zip.getEntry(required);
            if (entry == null || entry.isDirectory()) throw new IOException("Runtime bundle is missing " + required);
        }
    }

    private static Map<String, String> readSums(ZipFile zip) throws IOException {
        ZipEntry entry = zip.getEntry(SUMS);
        byte[] bytes;
        try (InputStream in = zip.getInputStream(entry)) { bytes = readLimited(in, 64 * 1024); }
        LinkedHashMap<String, String> result = new LinkedHashMap<String, String>();
        String text = new String(bytes, StandardCharsets.UTF_8);
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+", 2);
            if (parts.length != 2 || !parts[0].matches("[0-9a-fA-F]{64}")) throw new IOException("Malformed SHA256SUMS line");
            String name = parts[1].trim();
            while (name.startsWith("*")) name = name.substring(1);
            if (name.contains("/") || name.contains("..")) throw new IOException("Unsafe checksum member name: " + name);
            result.put(name, parts[0].toLowerCase(Locale.ROOT));
        }
        return result;
    }

    private static void requireChecksum(Map<String, String> sums, String name) throws IOException {
        if (!sums.containsKey(name)) throw new IOException("Missing SHA-256 for " + name);
    }

    private static void extractVerified(ZipFile zip, String name, String expectedSha, File output) throws IOException {
        ZipEntry entry = zip.getEntry(name);
        if (entry == null || entry.isDirectory()) throw new IOException("Runtime bundle member missing: " + name);
        long declared = entry.getSize();
        if (declared > MAX_MEMBER_BYTES) throw new IOException("Runtime bundle member too large: " + name);
        MessageDigest digest = sha256Digest();
        long total = 0L;
        try (InputStream in = new BufferedInputStream(zip.getInputStream(entry));
             OutputStream out = new BufferedOutputStream(new FileOutputStream(output))) {
            byte[] buffer = new byte[128 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                total += read;
                if (total > MAX_MEMBER_BYTES) throw new IOException("Runtime bundle member exceeds safety limit: " + name);
                digest.update(buffer, 0, read);
                out.write(buffer, 0, read);
            }
            out.flush();
        }
        String actual = hex(digest.digest());
        if (!actual.equals(expectedSha)) {
            if (output.exists()) output.delete();
            throw new IOException("SHA-256 mismatch for " + name);
        }
    }

    private static byte[] readLimited(InputStream in, int maxBytes) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int total = 0;
        int read;
        while ((read = in.read(buffer)) != -1) {
            total += read;
            if (total > maxBytes) throw new IOException("Runtime bundle metadata is too large");
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }

    private static MessageDigest sha256Digest() throws IOException {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (Exception e) { throw new IOException("SHA-256 unavailable", e); }
    }

    private static String hex(byte[] bytes) {
        StringBuilder out = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return out.toString();
    }

    private static boolean inside(File root, File child) throws IOException {
        String rp = root.getCanonicalPath();
        String cp = child.getCanonicalPath();
        return cp.equals(rp) || cp.startsWith(rp + File.separator);
    }

    private static void deleteRecursively(File file) throws IOException {
        if (java.nio.file.Files.isSymbolicLink(file.toPath())) {
            if (!file.delete()) throw new IOException("Cannot delete runtime staging symlink");
            return;
        }
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        if (file.exists() && !file.delete()) throw new IOException("Cannot delete runtime staging file: " + file);
    }

    public static final class InstallResult {
        private final String arch;
        private final int runtimeFiles;
        private final int runtimeSymlinks;
        private final int gradleVerifiedFiles;
        private final int sdkVerifiedFiles;
        private final String inventory;

        InstallResult(String arch, int runtimeFiles, int runtimeSymlinks,
                      int gradleVerifiedFiles, int sdkVerifiedFiles, String inventory) {
            this.arch = arch;
            this.runtimeFiles = runtimeFiles;
            this.runtimeSymlinks = runtimeSymlinks;
            this.gradleVerifiedFiles = gradleVerifiedFiles;
            this.sdkVerifiedFiles = sdkVerifiedFiles;
            this.inventory = inventory;
        }

        public String getArch() { return arch; }
        public int getRuntimeFiles() { return runtimeFiles; }
        public int getRuntimeSymlinks() { return runtimeSymlinks; }
        public int getGradleVerifiedFiles() { return gradleVerifiedFiles; }
        public int getSdkVerifiedFiles() { return sdkVerifiedFiles; }
        public String getInventory() { return inventory; }
    }
}
